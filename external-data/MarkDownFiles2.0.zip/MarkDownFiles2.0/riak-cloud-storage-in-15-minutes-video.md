---
title: "Riak Cloud Storage in 15 Minutes (Video)"
description: "Learn the basics of Riak Cloud Storage in this 15 minute video from the Citrix CloudPlatform partner program."
project: community
lastmod: 2015-05-28T19:24:09+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Riak"
pub_date: 2012-12-12T00:00:00+00:00
---
December 12, 2012
Learn the basics of Riak Cloud Storage in 15 minutes in this video from the Citrix CloudPlatform partner program. We discuss the building blocks of cloud services platforms and enterprise requirements for cloud storage. Then we walk through the properties, architecture, interfaces and operations of Riak CS.

If you want to try Riak CS, sign up for a developer trial to get up and running.
Riak Team
