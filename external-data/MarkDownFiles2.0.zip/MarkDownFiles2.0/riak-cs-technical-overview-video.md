---
title: "Riak CS: Technical Overview Video"
description: "Technical overview video of Riak CS."
project: community
lastmod: 2015-05-28T19:23:41+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Riak"
pub_date: 2013-03-28T16:00:26+00:00
---
March 28, 2013
In this video, Riak Chief Architect Andy Gross provides a technical overview of Riak CS, which we open sourced last week. This video was filmed at the CloudStack Collaboration Conference last November. It looks at Riak CS architecture, operations, interfaces and use cases, as well as our partnership with CloudStack. Slides and video are below, and make sure to check out new features we’ve added in the last release.

To learn more about Riak CS, visit the site or sign up for our webcast on April 2.
Riak
