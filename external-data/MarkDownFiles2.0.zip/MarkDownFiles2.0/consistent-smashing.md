---
title: "Consistent Smashing"
description: "July 28, 2010 Sometimes you need more than words to illustrate a point. Here is Riak's humble attempt to clarify the difference between "Dynamo-Style" systems (like Riak) that use consistent hashing to achieve fault tolerance, simple scaling, and prevent data loss, and systems that use techniques"
project: community
lastmod: 2015-05-28T19:24:16+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Mark Phillips"
pub_date: 2010-07-28T04:16:09+00:00
---
July 28, 2010
Sometimes you need more than words to illustrate a point. Here is Riak’s humble attempt to clarify the difference between “Dynamo-Style” systems (like Riak) that use consistent hashing to achieve fault tolerance, simple scaling, and prevent data loss, and systems that use techniques like sharding.
Enjoy!
Mark

Consistent Smashing from Riak Technologies on Vimeo.
