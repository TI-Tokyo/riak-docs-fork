---
title: "From Strange Loop to RICON: Yeah, I Think I See What You Mean"
description: "I've been thinking about Peter Alvaro's talk "I See What You Mean" since attending this year’s Strange Loop conference and I have a lot of say about it.  TL;DR is you should watch this talk and discuss it with us at RICON:  It's interesting to me that a significant number of talks in this y"
project: community
lastmod: 2016-09-30T07:21:16+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Mark Allen"
pub_date: 2015-10-13T11:59:27+00:00
---
I’ve been thinking about Peter Alvaro’s talk “I See What You Mean” since attending this year’s Strange Loop conference and I have a lot of say about it. 
TL;DR is you should watch this talk and discuss it with us at RICON:
