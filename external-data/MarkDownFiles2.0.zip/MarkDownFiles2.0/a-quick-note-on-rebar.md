---
title: "A Quick Note on Rebar"
description: "January 10, 2010 As many of you Erlang and Riak fans know, Dave Smith has been hard at work on Rebar. For those of you who don't know, Rebar is a truly cool packaging and build tool for Erlang applications. Dave took a break from coding this morning to post a few words on his blog Gradual Epiphan"
project: community
lastmod: 2015-05-28T19:24:19+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Mark Phillips"
pub_date: 2010-01-10T21:07:47+00:00
---
January 10, 2010
As many of you Erlang and Riak fans know, Dave Smith has been hard at work on Rebar. For those of you who don’t know, Rebar is a truly cool packaging and build tool for Erlang applications. Dave took a break from coding this morning to post a few words on his blog Gradual Epiphany about why he was inspired to write Rebar and what it means for building and deploying applications. Check it out. It’s a great read.
Also, if you haven’t had a chance to join the Rebar mailing list, you can do so here.
Mark
