---
title: "An Introduction To Stasis With Rusty Sears"
description: "November 14, 2012 The video from last week's RiakChats Meetup is ready for consumption. Rusty Sears was kind enough to join us for an overview of Stasis. Stasis is "a flexible transactional storage library that is geared toward high-performance applications and system developers." Rusty worked o"
project: community
lastmod: 2015-05-28T19:24:09+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Mark Phillips"
pub_date: 2012-11-14T06:32:55+00:00
---
November 14, 2012
The video from last week’s RiakChats Meetup is ready for consumption. Rusty Sears was kind enough to join us for an overview of Stasis. Stasis is “a flexible transactional storage library that is geared toward high-performance applications and system developers.” Rusty worked on it when he was at UC Berkeley and is now doing related work as part of Microsoft’s Cloud and Information Services Lab.
The talk runs just over 30 minutes, and is well worth your time. You’ll soon realize why Eric Brewer mentioned Stasis in his RICON2012 keynote as the type of framework that will be important for the next generation of distributed systems.
Enjoy, and make sure to sign up for RiakChats. When we announce January’s speaker, you’ll be glad you did…
Mark
 

