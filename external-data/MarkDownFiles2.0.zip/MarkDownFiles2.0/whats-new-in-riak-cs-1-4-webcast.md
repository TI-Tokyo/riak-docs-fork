---
title: ""What’s New in Riak CS 1.4" Webcast"
description: "Register for the "What's New in Riak CS 1.4" webcast on August 23rd."
project: community
lastmod: 2015-05-28T19:23:37+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Riak"
pub_date: 2013-08-14T17:44:24+00:00
---
August 14, 2013
Next week, we will be hosting the “What’s New in Riak CS 1.4” webcast. Join us on Friday, August 23rd at 11am PT/2pm ET for a free webcast that will discuss the new features and updates announced with the latest release. You can sign up for this 30-minute webcast here.
In addition to looking at the 1.4 updates, this webcast will discuss the basics of Riak CS and Riak CS Enterprise, while also providing some common use cases and user stories.
Register now for the “What’s New in Riak CS 1.4” webcast and learn more about this new release here.
Riak
