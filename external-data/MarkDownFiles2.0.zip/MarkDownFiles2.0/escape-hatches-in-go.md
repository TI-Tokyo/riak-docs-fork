---
title: "Escape Hatches In Go"
description: "July 10, 2012 I'm happy to report that the videos from the latest RiakChats are online and ready for consumption. The first off the queue is Jeff Hodges "Escape Hatches in Go" talk. This talk is on the shorter side, coming in at just under 25 minutes (questions included), and though it's not"
project: community
lastmod: 2015-05-28T19:24:11+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Mark Phillips"
pub_date: 2012-07-10T00:27:49+00:00
---
July 10, 2012
I’m happy to report that the videos from the latest RiakChats are online and ready for consumption. The first off the queue is Jeff Hodges “Escape Hatches in Go” talk.
This talk is on the shorter side, coming in at just under 25 minutes (questions included), and though it’s not a pure introduction to Go, all existing and prospective users of the language should find it useful in some capacity. And even if you don’t like or see yourself using Go, this is worth watching as Jeff brings a unique combination passion, knowledge, and honesty when speaking. (His talk from the May Boundary Meetup is another one you should watch if you haven’t already done so.)
Neil’s talk will be up later this week time permitting…
Enjoy.
Mark
 

