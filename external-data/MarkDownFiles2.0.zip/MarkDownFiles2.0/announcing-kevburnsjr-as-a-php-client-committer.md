---
title: "Announcing KevBurnsJr as a PHP Client Committer"
description: "We just added Kevin Burns as a committer to the Riak-supported Riak PHP Client. Kevin has been hard at work over the past few weeks adding some great functionality to the PHP client..."
project: community
lastmod: 2015-05-28T19:24:15+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Mark Phillips"
pub_date: 2011-02-28T20:44:57+00:00
---
February 28, 2011
We just added Kevin Burns, who goes by KevBurnsJr on Github, Twitter and the #riak IRC room on irc.freenode.net, as a committer to the Riak-supported Riak PHP Client.
Kevin has been hard at work over the past few weeks adding some great functionality to the PHP client and has even kicked off porting Ripple, Riak’s Ruby Client ODM, to PHP. Suffice it to say that we at Riak are excited about Kevin’s participation and involvement with Riak and our PHP code.
Some relevant code:
\* Riak’s PHP Client
\* Port of Ripple to PHP
Thank, Kev! We are looking forward to your contributions.
Mark
 
