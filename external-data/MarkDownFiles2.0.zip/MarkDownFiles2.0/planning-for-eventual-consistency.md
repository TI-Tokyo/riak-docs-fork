---
title: "Planning for Eventual Consistency"
description: "May 14, 2010 You may remember that last week, we recorded a podcast with Benjamin Black all about the immense variety of databases in the NoSQL space and what your criteria should be when choosing one. If you listened carefully, you may also remember that Benjamin and Justin Sheehy started to d"
project: community
lastmod: 2015-05-28T19:24:17+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Mark Phillips"
pub_date: 2010-05-14T01:28:31+00:00
---
May 14, 2010
You may remember that last week, we recorded a podcast with Benjamin Black all about the immense variety of databases in the NoSQL space and what your criteria should be when choosing one.
If you listened carefully, you may also remember that Benjamin and Justin Sheehy started to discuss eventual consistency. We decided to roll that into its own podcast as we thought it was a topic worthy of its own episode.
Think there are only a certain subset of databases that are “eventually consistent”? Think again. Regardless of the database you choose, eventual consistency is something you should embrace and plan for, not fear.
Listen, Learn, and Enjoy – –
Mark


If you are having problems getting the podcast to play, click here to play in new window or right click to download the podcast.
