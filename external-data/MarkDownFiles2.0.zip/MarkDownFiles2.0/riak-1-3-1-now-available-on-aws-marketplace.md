---
title: "Riak 1.3.1 Now Available on AWS Marketplace"
description: "May 6, 2013 The free Riak AMI available on the AWS Marketplace has been updated to the latest version, Riak 1.3.1. In Riak 1.3, we introduced: 	Active Anti-Entropy 	Updates to Riak Control 	Expanded IPv6 support 	Improved MapReduce 	Simplified Log Management Riak 1.3.1 includes all t"
project: community
lastmod: 2015-05-28T19:23:39+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Riak"
pub_date: 2013-05-06T16:22:42+00:00
---
May 6, 2013
The free Riak AMI available on the AWS Marketplace has been updated to the latest version, Riak 1.3.1.
In Riak 1.3, we introduced:

Active Anti-Entropy
Updates to Riak Control
Expanded IPv6 support
Improved MapReduce
Simplified Log Management

Riak 1.3.1 includes all these features with some additional changes enumerated in the release notes.
For those of you currently using Riak on AWS, or interested in testing Riak on AWS, the AMI makes installation and configuration much easier. We see open source and Riak Enterprise users leverage AWS both as their primary infrastructure and to support hybrid implementations.
Installation instructions for the AMI are available on in our docs.
Riak
