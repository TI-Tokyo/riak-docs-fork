---
title: "Riak Community Release Notes v0.3"
description: "June 4, 2012 I'm thrilled to announce that the v0.3 Riak Community Release Notes are now official. (For some history on the Community Release Notes, go here.) This installment covers what happened in the community from (approximately) May 4 through June 1. Some of the many stand-out accomplishmen"
project: community
lastmod: 2016-07-31T22:23:06+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Mark Phillips"
pub_date: 2012-06-04T00:00:00+00:00
---
June 4, 2012
I’m thrilled to announce that the v0.3 Riak Community Release Notes are now official. (For some history on the Community Release Notes, go here.) This installment covers what happened in the community from (approximately) May 4 through June 1. Some of the many stand-out accomplishments from this release:

The team at Kiip gave a great talk on moving from MongoDB to Riak.
Long-time Riak and Riak Search users and contributors Cliboard officially launched.
The first Riak London Meetup was held.
Mathias Meyer shipped a huge update to the Riak Handbook.
Matt Ranney and the team at Voxer released their Node.js client for Riak.

We did a lot more. Take a few minutes to read up. Also, we’re already rolling with the 0.4 Release Notes (which will cover June 2 up through July 1). You’re encouraged to contribute to past, present, and future release notes, so don’t hold back.
Enjoy, and thanks for being a part of Riak.
Mark
