---
title: "Official Riak Package Repositories Now Available"
description: "We are pleased to announce that Riak package repositories for Riak downloads are now available! Hopefully this makes installing Riak even easier. Here's the summary of what's currently available"
project: community
lastmod: 2015-05-28T19:24:10+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "James S. Martin"
pub_date: 2012-10-16T00:00:00+00:00
---
October 16, 2012
We are pleased to announce that Riak package repositories for Riak downloads are now available! Hopefully this makes installing Riak even easier. Here’s the summary of what’s currently available:
RHEL 5 and clones
Riak EL5 Release Package

RHEL 6 and clones
Riak EL6 Release Package

then install riak

Debian / Ubuntu:
get the signing key:

add the repository to your system:

then install Riak


This information will soon be added to the Riak Docs, but we couldn’t wait to share the good news.
Enjoy and thanks for being a part of Riak.
James
