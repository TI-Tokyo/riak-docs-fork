---
title: "NoSQL and Endless Variety"
description: "A Conversation about Variety and Making Choices Benjamin Black stopped by the Riak offices recently and we had the chance to sit him down and discuss the collection of things that is "NoSQL." In this, the fifth installment of the Riak Riak Podcast, Benjamin and Riak's CTO Justin Sheehy discus"
project: community
lastmod: 2015-11-05T10:41:52+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Mark Phillips"
pub_date: 2010-05-07T01:25:03+00:00
---
A Conversation about Variety and Making Choices
Benjamin Black stopped by the Riak offices recently and we had the chance to sit him down and discuss the collection of things that is “NoSQL.”
In this, the fifth installment of the Riak Riak Podcast, Benjamin and Riak’s CTO Justin Sheehy discuss the factors that they think should play the largest part in your evaluation of any database, NoSQL or otherwise. (Hint: it’s not name recognition.)
Highlights include why and when you might be best served improving your relational database architecture and when it might be better to use a NoSQL system like Cassandra or Riak to solve part of your problem, as well as why you probably don’t want to figure out which one of the NoSQL systems solves all of your problems.
Enjoy,
Mark


If you are having problems getting the podcast to play, click here to play in new window or right click to download the podcast.
