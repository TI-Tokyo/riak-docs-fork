---
title: "Dave Smith Gives a General Overview of Rebar"
description: "December 21, 2009 As a follow up to my first screencast on using Rebar for embedded Riak nodes, this video gives a more general overview of Rebar using ibrowse, an existing Erlang application, to show functionality and intended uses. Enjoy, Dave  (View on Vimeo)"
project: community
lastmod: 2015-05-28T19:24:19+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Riak"
pub_date: 2009-12-21T20:56:42+00:00
---
December 21, 2009
As a follow up to my first screencast on using Rebar for embedded Riak nodes, this video gives a more general overview of Rebar using ibrowse, an existing Erlang application, to show functionality and intended uses.
Enjoy,
Dave

(View on Vimeo)
