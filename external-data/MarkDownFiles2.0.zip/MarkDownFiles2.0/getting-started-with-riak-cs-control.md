---
title: "Getting Started with Riak CS Control"
description: "A short video to get you started with Riak CS Control."
project: community
lastmod: 2015-05-28T19:23:40+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Riak"
pub_date: 2013-04-16T10:00:33+00:00
---
April 17, 2013
Riak CS Control is a standalone user management interface for Riak CS, Riak’s cloud storage software. Riak CS Control provides a user interface for filtering, disabling, creating, and managing users.
To help get you started with Riak CS Control, we have put together a short video that walks you through the installation and configuration. It also goes over the basics of how to create and manage users.

For more information on Riak CS, sign up for our Riak CS Intro webcast on April 23rd or visit the Riak CS page.
Riak
