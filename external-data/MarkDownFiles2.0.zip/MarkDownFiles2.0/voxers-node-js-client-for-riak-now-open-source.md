---
title: "Voxer's Node.js Client For Riak Now Open Source"
description: "I'm excited to announce that Matt Rannay and the team at Voxer just open-sourced their production node.js client for Riak, node_riak."
project: community
lastmod: 2015-05-28T19:24:12+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Mark Phillips"
pub_date: 2012-05-14T00:00:00+00:00
---
May 14, 2012
I’m excited to announce that Matt Ranney and the team at Voxer just open-sourced their production Node.js client for Riak, node\_riak. Voxer has been using this code in production for months now, and it has been battle-tested with Riak clusters doing billions of requests daily and that are storing on the order of 100s of terabytes of raw data.
In addition to more code, Matt and his team will be working to add documentation and other resources to the repo as time allows. Interested parties are encouraged to fork, use, and contribute.
Enjoy, and thanks again to Matt and his team for releasing the library. Here’s the link to the repo once more: node\_riak
Also, if you want to work with Riak, Node.js, and other technologies that power Voxer, check out their job listings. You won’t be disappointed.
Mark
