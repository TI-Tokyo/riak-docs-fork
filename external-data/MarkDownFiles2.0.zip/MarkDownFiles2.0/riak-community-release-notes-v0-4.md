---
title: "Riak Community Release Notes v0.4"
description: "July 6, 2012 I'm excited to announce that v0.4 of the Riak Community Release Notes are official, covering what happened in the Riak Community from approximately June 1 thru June 30. Some highlights include: 	Matt Ranney and Ryan Sokol discussed Riak in Production at Voxer. 	Sean Cribbs gave a"
project: community
lastmod: 2015-05-28T19:24:11+00:00
sitemap:
  priority: 0.2
project_section: technicalblogpost
author_name: "Tom Santero"
pub_date: 2012-07-06T00:00:00+00:00
---
July 6, 2012
I’m excited to announce that v0.4 of the Riak Community Release Notes are official, covering what happened in the Riak Community from approximately June 1 thru June 30. Some highlights include:

Matt Ranney and Ryan Sokol discussed Riak in Production at Voxer.
Sean Cribbs gave a talk on CRDT’s at Berlin Buzzwords.
The inaugural Paris Riak Meetup was held.
The team at Near Infinity wrote a good introduction to Riak.

The community also shipped a bunch of code during the month of June, so if you have a few minutes read what else the Riak Community accomplished. Also, we’re already rolling with the 0.5 Release Notes (which will cover July 2 up through August 1). You’re encouraged to contribute to past, present, and future release notes, so don’t hold back.
Enjoy, and thanks for being a part of Riak.
Tom
